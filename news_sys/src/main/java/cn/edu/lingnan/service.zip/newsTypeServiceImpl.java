package cn.edu.lingnan.service;

import cn.edu.lingnan.dao.NewsTypeDao;
import cn.edu.lingnan.dao.NewsTypeDaoImpl;
import cn.edu.lingnan.pojo.newsType;

import java.util.Vector;

public class newsTypeServiceImpl implements newsTypeService {

    NewsTypeDao newsTypeDao = new NewsTypeDaoImpl();
    @Override
    public Vector<newsType> selectAllNewsType() {
        return newsTypeDao.selectAllNewsType();
    }

    @Override
    public newsType selectNewsTypeById(int typeId) {
        return newsTypeDao.selectNewsTypeById(typeId);
    }

    @Override
    public Vector<newsType> selectNewsTypeByName(String typeName) {
        return newsTypeDao.selectNewsTypeByName(typeName);
    }

    @Override
    public int updateNewsType(newsType newsType) {
        return newsTypeDao.updateNewsType(newsType);
    }

    @Override
    public int deleteNewsType(int typeId) {
        return newsTypeDao.deleteNewsType(typeId);
    }

    @Override
    public int insertNewsType(newsType newsType) {
        return newsTypeDao.insertNewsType(newsType);
    }
}
