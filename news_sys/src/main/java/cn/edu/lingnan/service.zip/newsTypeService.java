package cn.edu.lingnan.service;

import cn.edu.lingnan.pojo.newsType;

import java.util.Vector;

public interface newsTypeService {
    /*查询所有新闻类型*/
    Vector<newsType> selectAllNewsType();

    /*根据类型编号查询新闻类型*/
    newsType selectNewsTypeById(int typeId);

    /*根据类型名称查询新闻类型*/
    Vector<newsType> selectNewsTypeByName(String typeName);

    /*修改新闻类型*/
    int updateNewsType(newsType newsType);

    /*删除新闻类型*/
    int deleteNewsType(int typeId);

    /*新增新闻类型*/
    int insertNewsType(newsType newsType);
}
