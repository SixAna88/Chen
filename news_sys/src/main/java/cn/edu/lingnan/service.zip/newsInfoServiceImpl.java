package cn.edu.lingnan.service;

import cn.edu.lingnan.dao.NewsInfoDao;
import cn.edu.lingnan.dao.NewsInfoDaoImpl;
import cn.edu.lingnan.pojo.newsInfo;

import java.util.Vector;

public class newsInfoServiceImpl implements newsInfoService {

    NewsInfoDao newsInfoDao = new NewsInfoDaoImpl();
    @Override
    public Vector<newsInfo> selectAllNewsInfo() {
        return newsInfoDao.selectAllNewsInfo();
    }

    @Override
    public newsInfo selectNewsInfoById(int newsId) {
        return newsInfoDao.selectNewsInfoById(newsId);
    }

    @Override
    public Vector<newsInfo> selectNewsInfoByTitle(String newsTitle) {
        return newsInfoDao.selectNewsInfoByTitle(newsTitle);
    }

    @Override
    public Vector<newsInfo> selectNewsInfoByTypeId(int typeId) {
        return newsInfoDao.selectNewsInfoByTypeId(typeId);
    }

    @Override
    public int updateNewsInfo(newsInfo newsInfo) {
        return newsInfoDao.updateNewsInfo(newsInfo);
    }

    @Override
    public int deleteNewsInfo(int newsId) {
        return newsInfoDao.deleteNewsInfo(newsId);
    }

    @Override
    public int insertNewsInfo(newsInfo newsInfo) {
        return newsInfoDao.insertNewsInfo(newsInfo);
    }
}
