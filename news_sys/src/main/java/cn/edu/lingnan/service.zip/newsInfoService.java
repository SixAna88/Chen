package cn.edu.lingnan.service;

import cn.edu.lingnan.pojo.newsInfo;

import java.util.Vector;

public interface newsInfoService {
    /*查询所有新闻信息*/
    Vector<newsInfo> selectAllNewsInfo();

    /*根据新闻编号查询新闻信息*/
    newsInfo selectNewsInfoById(int newsId);

    /*根据新闻标题关键字查询新闻信息*/
    Vector<newsInfo> selectNewsInfoByTitle(String newsTitle);

    /*根据新闻类型编号关键字查询新闻信息*/
    Vector<newsInfo> selectNewsInfoByTypeId(int typeId);

    /*修改新闻信息*/
    int updateNewsInfo(newsInfo newsInfo);

    /*删除新闻信息*/
    int deleteNewsInfo(int newsId);

    /*新增新闻信息*/
    int insertNewsInfo(newsInfo newsInfo);
}
